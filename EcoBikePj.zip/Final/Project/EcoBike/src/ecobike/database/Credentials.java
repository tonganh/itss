package ecobike.database;

public class Credentials {
    public static final String USERNAME = "root";
    public static final String PASSWORD = "example";

}
