package ecobike.user.station.list;

import ecobike.abstracts.ATableData;

import javax.swing.*;

public class StationTableData extends ATableData {

    public StationTableData(String[] col, JTable table) {
        super(col, table);
    }

}
