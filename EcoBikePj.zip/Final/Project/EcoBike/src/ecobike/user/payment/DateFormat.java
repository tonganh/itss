package ecobike.user.payment;

public class DateFormat {

    public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
}
