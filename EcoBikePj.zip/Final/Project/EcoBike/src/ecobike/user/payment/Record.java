//package ecobike.user.payment;
//
//public class Record {
//
//    private int recordId;
//    private int userId;
//    private int accountId;
//    private int bikeId;
//    private String startTime;
//    private String endTime;
//    private String totalTime;
//    private String fee;
//
//    public Record() {
//
//    }
//
//    public Record(int recordId, int userId, int accountId, int bikeId, String startTime, String endTime, String totalTime, String fee) {
//        super();
//        this.recordId = recordId;
//        this.userId = userId;
//        this.accountId = accountId;
//        this.bikeId = bikeId;
//        this.startTime = startTime;
//        this.endTime = endTime;
//        this.totalTime = totalTime;
//        this.fee = fee;
//    }
//
//    public int getRecordId() {
//        return recordId;
//    }
//
//    public void setRecordId(int recordId) {
//        this.recordId = recordId;
//    }
//
//    public int getUserId() {
//        return userId;
//    }
//
//    public void setUserId(int userId) {
//        this.userId = userId;
//    }
//
//    public int getAccountId() {
//        return accountId;
//    }
//
//    public void setAccountId(int accountId) {
//        this.accountId = accountId;
//    }
//
//    public int getBikeId() {
//        return bikeId;
//    }
//
//    public void setBikeId(int bikeId) {
//        this.bikeId = bikeId;
//    }
//
//    public String getStartTime() {
//        return startTime;
//    }
//
//    public void setStartTime(String startTime) {
//        this.startTime = startTime;
//    }
//
//    public String getEndTime() {
//        return endTime;
//    }
//
//    public void setEndTime(String endTime) {
//        this.endTime = endTime;
//    }
//
//    public String getTotalTime() {
//        return totalTime;
//    }
//
//    public void setTotalTime(String totalTime) {
//        this.totalTime = totalTime;
//    }
//
//    public String getFee() {
//        return fee;
//    }
//
//    public void setFee(String fee) {
//        this.fee = fee;
//    }
//}
