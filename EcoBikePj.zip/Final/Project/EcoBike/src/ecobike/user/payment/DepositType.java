package ecobike.user.payment;

public class DepositType {

    public static final int NORMALBIKE_DEPOSIT = 400000;
    public static final int ECOBIKE_DEPOSIT = 700000;
    public static final int TWINBIKE_DEPOSIT = 550000;
}
