package ecobike.bean;

public class TwinBike extends Bike {

    public TwinBike() {
        super();
        // TODO Auto-generated constructor stub
    }

    public TwinBike(int bikeID, String name, float weight, String licensePlate, String manufacturingDate,
            String producer, int stationID) {
        super(bikeID, name, weight, licensePlate, manufacturingDate, producer, stationID);
        // TODO Auto-generated constructor stub
    }

}
